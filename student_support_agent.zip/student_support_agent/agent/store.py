"""Tiny JSON-file persistence layer: students, memory, support requests,
approvals, audit log and traces. Everything lives in one runtime folder."""
import json, shutil, time, uuid
from pathlib import Path

SEED = Path(__file__).resolve().parent.parent / "data"
DEFAULT_RUNTIME = Path(__file__).resolve().parent.parent / "runtime"


class Store:
    def __init__(self, runtime_dir=DEFAULT_RUNTIME, fresh=False):
        self.dir = Path(runtime_dir)
        if fresh and self.dir.exists():
            shutil.rmtree(self.dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        if not (self.dir / "students.json").exists():
            shutil.copy(SEED / "students.json", self.dir / "students.json")

    # ---- generic json helpers
    def _read(self, name, default):
        p = self.dir / name
        return json.loads(p.read_text()) if p.exists() else default

    def _write(self, name, obj):
        (self.dir / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False))

    def _append(self, name, rec):
        with open(self.dir / name, "a") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def _read_lines(self, name):
        p = self.dir / name
        return [json.loads(l) for l in p.read_text().splitlines()] if p.exists() else []

    # ---- students
    def students(self):
        return self._read("students.json", {})

    def save_students(self, d):
        self._write("students.json", d)

    # ---- long-term memory (per student)
    def memory(self, sid):
        return self._read("memory.json", {}).get(sid, {})

    def memory_set(self, sid, key, value):
        m = self._read("memory.json", {})
        m.setdefault(sid, {})[key] = {"value": value, "ts": time.strftime("%Y-%m-%d %H:%M:%S")}
        self._write("memory.json", m)

    # ---- support requests
    def add_support_request(self, sid, category, description):
        reqs = self._read("support_requests.json", [])
        rec = {"id": "SR-" + uuid.uuid4().hex[:6].upper(), "student_id": sid,
               "category": category, "description": description,
               "status": "Open", "created": time.strftime("%Y-%m-%d %H:%M:%S")}
        reqs.append(rec)
        self._write("support_requests.json", reqs)
        return rec

    def support_requests(self):
        return self._read("support_requests.json", [])

    # ---- approvals
    def approvals(self):
        return self._read("approvals.json", [])

    def add_approval(self, rec):
        a = self.approvals(); a.append(rec); self._write("approvals.json", a)

    def update_approval(self, aid, **changes):
        a = self.approvals()
        for r in a:
            if r["id"] == aid:
                r.update(changes)
        self._write("approvals.json", a)

    def get_approval(self, aid):
        return next((r for r in self.approvals() if r["id"] == aid), None)

    # ---- audit + traces
    def audit(self, **fields):
        rec = {"audit_id": "AUD-" + uuid.uuid4().hex[:6].upper(),
               "ts": time.strftime("%Y-%m-%d %H:%M:%S"), **fields}
        self._append("audit.jsonl", rec)
        return rec

    def audit_log(self):
        return self._read_lines("audit.jsonl")

    def add_trace(self, rec):
        self._append("traces.jsonl", rec)

    def traces(self):
        return self._read_lines("traces.jsonl")
