"""The agent loop: select context -> call model -> run tools (through the
secure gateway) -> repeat until the model answers. Every run writes a trace."""
import time, uuid
from dataclasses import dataclass, field
from .retrieval import tokenize
from .security import redact, Session
from .tools import Ctx, TOOL_SCHEMAS, run_tool

BASE_PROMPT = """You are the Student Support Agent of a PGDM programme office. Be concise and friendly.
- Use tools for any fact about a student's record, fees or scholarship. Never guess.
- For policy questions call search_policy and answer ONLY from the retrieved text. If it is not covered, say so and offer to raise a support request.
- Use save_memory only for durable facts or preferences (programme, preferred contact, language, interests), never for temporary or sensitive things."""

SECURE_RULES = """
SECURITY RULES (also enforced by the application code):
- You are serving ONLY the signed-in student named below. Never request or reveal another student's data.
- Record changes are submitted for staff approval. Tell the student the change is PENDING, never that it is done.
- Never ask for or store passwords, OTPs or card numbers. Text shown as [REDACTED_...] had a secret removed."""


@dataclass
class Chat:
    session: Session
    history: list = field(default_factory=list)   # only redacted user text + final answers


def select_memory(store, sid, query, k=3):
    """Context selection for long-term memory: only items that overlap the question."""
    q = set(tokenize(query)); scored = []
    for key, item in store.memory(sid).items():
        overlap = len(q & set(tokenize(key.replace("_", " ") + " " + item["value"])))
        if overlap:
            scored.append((overlap, key, item["value"]))
    return [(k_, v) for _, k_, v in sorted(scored, reverse=True)[:k]]


class Agent:
    def __init__(self, store, retriever, llm, controls=True, max_steps=6, history_turns=4):
        self.store, self.retriever, self.llm = store, retriever, llm
        self.controls, self.max_steps, self.history_turns = controls, max_steps, history_turns

    def new_chat(self, session):
        return Chat(session)

    def chat(self, chat, user_text):
        t0 = time.perf_counter()
        run_id = "RUN-" + uuid.uuid4().hex[:6].upper()
        s = chat.session
        clean, redactions = redact(user_text) if self.controls else (user_text, [])
        mem = select_memory(self.store, s.student_id, clean)
        system = BASE_PROMPT
        if self.controls:
            system += SECURE_RULES + f"\nSigned-in student: {s.name} ({s.student_id})."
        if mem:
            system += "\nRemembered about this student (long-term memory):\n" + "\n".join(f"- {k}: {v}" for k, v in mem)

        ctx = Ctx(self.store, s, self.retriever, self.controls, run_id)
        messages = chat.history[-2 * self.history_turns:] + [{"role": "user", "content": clean}]
        tin = tout = calls = 0
        answer = "Sorry, I could not complete that request."
        for _ in range(self.max_steps):
            r = self.llm.create(system, messages, TOOL_SCHEMAS)
            tin += r.input_tokens; tout += r.output_tokens; calls += 1
            if r.stop_reason != "tool_use":
                answer = " ".join(b["text"] for b in r.content if b["type"] == "text").strip() or answer
                break
            messages.append({"role": "assistant", "content": r.content})
            results = []
            for b in r.content:
                if b["type"] == "tool_use":
                    import json
                    out = run_tool(ctx, b["name"], b["input"])
                    results.append({"type": "tool_result", "tool_use_id": b["id"], "content": json.dumps(out)})
            messages.append({"role": "user", "content": results})

        chat.history += [{"role": "user", "content": clean}, {"role": "assistant", "content": answer}]
        latency = round(time.perf_counter() - t0, 3)
        trace = {"run_id": run_id, "student": s.student_id, "question": clean, "redactions": redactions,
                 "tools": ctx.steps, "policy_chunks": sorted(set(ctx.evidence)),
                 "memory_used": [k for k, _ in mem], "llm_calls": calls,
                 "input_tokens": tin, "output_tokens": tout, "latency_s": latency, "answer": answer,
                 "controls": self.controls}
        self.store.add_trace(trace)
        return trace
