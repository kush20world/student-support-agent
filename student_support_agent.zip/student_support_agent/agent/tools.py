"""Tools the agent can call + the single gateway `run_tool` that applies
authorization, approval and audit logging in ordinary Python code."""
from dataclasses import dataclass, field
from .security import authorize, is_sensitive, redact, Session

ALLOWED_MEMORY_KEYS = {"programme", "preferred_name", "preferred_contact", "language", "interests", "career_goal"}
EDITABLE_FIELDS = {"email", "phone", "elective", "programme"}

TOOL_SCHEMAS = [
    {"name": "search_policy", "description": "Search the student policy handbook. Use for any question about rules, deadlines, late fees, scholarships rules, course changes, procedures.",
     "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}},
    {"name": "get_student_record", "description": "Get the signed-in student's profile (programme, email, phone, elective).",
     "input_schema": {"type": "object", "properties": {"student_id": {"type": "string", "description": "Only if the user names a student ID"}}}},
    {"name": "get_fee_status", "description": "Get fee total, paid, due amount, due date and status.",
     "input_schema": {"type": "object", "properties": {"student_id": {"type": "string"}}}},
    {"name": "get_scholarship_status", "description": "Get scholarship name, status, amount and disbursement.",
     "input_schema": {"type": "object", "properties": {"student_id": {"type": "string"}}}},
    {"name": "create_support_request", "description": "Create a support ticket for the programme office.",
     "input_schema": {"type": "object", "properties": {"category": {"type": "string", "enum": ["fees", "scholarship", "course", "other"]},
                                                         "description": {"type": "string"}}, "required": ["category", "description"]}},
    {"name": "request_record_change", "description": "Request a change to a student record field (email, phone, elective, programme). SENSITIVE: needs staff approval, it is not applied immediately.",
     "input_schema": {"type": "object", "properties": {"field": {"type": "string", "enum": sorted(EDITABLE_FIELDS)},
                                                         "new_value": {"type": "string"}, "reason": {"type": "string"},
                                                         "student_id": {"type": "string"}}, "required": ["field", "new_value"]}},
    {"name": "save_memory", "description": "Save a durable fact worth remembering across sessions (programme, preferred contact method, language, interests). Never for temporary or sensitive info.",
     "input_schema": {"type": "object", "properties": {"key": {"type": "string", "enum": sorted(ALLOWED_MEMORY_KEYS)},
                                                         "value": {"type": "string"}}, "required": ["key", "value"]}},
]


@dataclass
class Ctx:
    store: object
    session: Session
    retriever: object
    controls: bool = True
    run_id: str = ""
    evidence: list = field(default_factory=list)   # policy chunk ids used in this run
    steps: list = field(default_factory=list)      # tool-call trace for this run


def _target(ctx, args):
    return (args.get("student_id") or ctx.session.student_id).strip().upper()


# ---- handlers ---------------------------------------------------------------
def search_policy(ctx, args):
    hits = ctx.retriever.search(args.get("query", ""))
    ctx.evidence += [h["id"] for h in hits]
    if not hits:
        return {"chunks": [], "note": "No relevant policy found in the handbook."}
    return {"chunks": [{"id": h["id"], "title": h["title"], "text": h["text"]} for h in hits]}


def _student(ctx, args):
    s = ctx.store.students().get(_target(ctx, args))
    if not s or s.get("role") != "student":
        raise LookupError("student record not found")
    return s


def get_student_record(ctx, args):
    s = _student(ctx, args)
    return {"student_id": _target(ctx, args), **{k: s[k] for k in ("name", "programme", "email", "phone", "elective")}}


def get_fee_status(ctx, args):
    return {"student_id": _target(ctx, args), **_student(ctx, args)["fees"]}


def get_scholarship_status(ctx, args):
    return {"student_id": _target(ctx, args), **_student(ctx, args)["scholarship"]}


def create_support_request(ctx, args):
    desc = redact(args["description"])[0] if ctx.controls else args["description"]
    r = ctx.store.add_support_request(_target(ctx, args), args.get("category", "other"), desc)
    return {"status": "created", "request_id": r["id"]}


def _apply_change(store, sid, fld, value):
    d = store.students(); d[sid][fld] = value; store.save_students(d)


def request_record_change(ctx, args):
    fld, new = args["field"], args["new_value"]
    if fld not in EDITABLE_FIELDS:
        return {"error": "invalid_field", "message": f"{fld} cannot be changed"}
    sid = _target(ctx, args); s = _student(ctx, args)
    if not ctx.controls:                      # Assignment-1 behaviour: executes immediately
        _apply_change(ctx.store, sid, fld, new)
        return {"status": "applied", "field": fld, "new_value": new}
    import uuid
    aid = "APR-" + uuid.uuid4().hex[:6].upper()
    ctx.store.add_approval({"id": aid, "student_id": sid, "field": fld, "old_value": s[fld], "new_value": new,
                            "reason": args.get("reason", ""), "status": "pending", "run_id": ctx.run_id})
    return {"status": "approval_required", "approval_id": aid,
            "message": "Change NOT applied. Waiting for programme-office approval."}


def save_memory(ctx, args):
    key, value = args["key"], str(args["value"])
    if ctx.controls:
        if key not in ALLOWED_MEMORY_KEYS:
            return {"error": "memory_rejected", "message": "key is not an allowed long-term memory type"}
        if is_sensitive(value):
            return {"error": "memory_rejected", "message": "sensitive information is never stored"}
    ctx.store.memory_set(ctx.session.student_id, key, value)
    return {"status": "saved", "key": key}


HANDLERS = {f.__name__: f for f in (search_policy, get_student_record, get_fee_status, get_scholarship_status,
                                    create_support_request, request_record_change, save_memory)}


def _safe_args(args):
    return {k: (redact(v)[0] if isinstance(v, str) else v) for k, v in args.items()}


def run_tool(ctx, name, args):
    """Gateway: authorize -> execute -> audit. Returns a JSON-able dict for the model."""
    actor = ctx.session.student_id
    decision = authorize(ctx.session, name, args, ctx.controls)
    if not decision.allowed:
        result = {"error": "permission_denied", "message": decision.reason}
        if ctx.controls:
            ctx.store.audit(run_id=ctx.run_id, actor=actor, tool=name, args=_safe_args(args), decision="denied",
                            reason=decision.reason, approval_status=None, result="blocked - not executed")
    else:
        try:
            result = HANDLERS[name](ctx, args)
        except Exception as e:
            result = {"error": "tool_error", "message": str(e)}
        if ctx.controls:
            pending = result.get("status") == "approval_required"
            rejected = result.get("error") == "memory_rejected"
            ctx.store.audit(run_id=ctx.run_id, actor=actor, tool=name, args=_safe_args(args),
                            decision="approval_required" if pending else "denied" if rejected else "allowed",
                            reason=result.get("message", "") if rejected else "",
                            approval_status="pending" if pending else None,
                            result=("pending approval - not executed" if pending else
                                    "error: " + result["message"] if "error" in result else "success"))
    ctx.steps.append({"tool": name, "args": _safe_args(args) if ctx.controls else args,
                      "decision": "denied" if not decision.allowed else "allowed",
                      "ok": "error" not in result})
    return result


def resolve_approval(store, approver, approval_id, approve, controls=True):
    """Human-in-the-loop step. Only staff may decide; the stored action is
    executed ONLY when approved."""
    rec = store.get_approval(approval_id)
    base = dict(run_id=rec["run_id"] if rec else None, actor=approver.student_id, tool="approval_decision",
                args={"approval_id": approval_id})
    if approver.role != "staff":
        store.audit(**base, decision="denied", reason="only staff may approve", approval_status=None, result="not executed")
        return {"error": "permission_denied"}
    if not rec or rec["status"] != "pending":
        store.audit(**base, decision="denied", reason="unknown or already-resolved approval", approval_status=None, result="not executed")
        return {"error": "not_pending"}
    if approve:
        _apply_change(store, rec["student_id"], rec["field"], rec["new_value"])
        store.update_approval(approval_id, status="approved", decided_by=approver.student_id)
        store.audit(**base, decision="allowed", reason=f"{rec['field']} change for {rec['student_id']}",
                    approval_status="approved", result="executed")
        return {"status": "approved", "executed": True}
    store.update_approval(approval_id, status="rejected", decided_by=approver.student_id)
    store.audit(**base, decision="allowed", reason=f"{rec['field']} change for {rec['student_id']}",
                approval_status="rejected", result="NOT executed (rejected)")
    return {"status": "rejected", "executed": False}
