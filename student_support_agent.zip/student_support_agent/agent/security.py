"""Assignment 2 controls that live in normal application code (not in the prompt):
  * identity (Session) + login check
  * authorization decision for every tool call
  * redaction of secrets (OTP, password, card numbers ...) before anything is
    sent to the model, logged, or stored."""
import hashlib, re
from dataclasses import dataclass

SALT = "sss-demo-salt"
PRIVATE_TOOLS = {"get_student_record", "get_fee_status", "get_scholarship_status",
                 "create_support_request", "request_record_change", "save_memory"}


def hash_pin(pin):
    return hashlib.sha256((SALT + pin).encode()).hexdigest()


@dataclass
class Session:
    student_id: str
    name: str
    role: str  # "student" | "staff"


def authenticate(store, user_id, pin):
    u = store.students().get(user_id.strip().upper())
    if u and u["pin_hash"] == hash_pin(pin):
        return Session(user_id.strip().upper(), u["name"], u["role"])
    return None


@dataclass
class Decision:
    allowed: bool
    reason: str = ""


def authorize(session, tool, args, controls=True):
    """Deny any private tool call that targets a record other than the
    signed-in student's, whatever the model asked for."""
    if not controls or tool not in PRIVATE_TOOLS:
        return Decision(True)
    if session.role != "student":
        return Decision(False, f"role '{session.role}' cannot use student tools")
    target = (args.get("student_id") or session.student_id).strip().upper()
    if target != session.student_id:
        return Decision(False, f"{session.student_id} is not allowed to access records of {target}")
    return Decision(True)


# ---- secret redaction -------------------------------------------------------
_PATTERNS = [
    (re.compile(r"\b(?:otp|one[- ]time[- ](?:password|code)|verification code)\b[^0-9\n]{0,25}\d{4,8}", re.I), "[REDACTED_OTP]"),
    (re.compile(r"\b\d{4,8}\b(?=\s+(?:is|was)\s+(?:my|the)\s+(?:otp|code))", re.I), "[REDACTED_OTP]"),
    (re.compile(r"\b(?:password|passwd|pwd|passcode|pin|cvv)\s*(?:is|:|=)\s*\S+", re.I), "[REDACTED_SECRET]"),
    (re.compile(r"\b(?:\d[ -]?){13,19}\b"), "[REDACTED_CARD]"),
]


def redact(text):
    """Return (clean_text, list_of_redaction_labels)."""
    found = []
    for pat, label in _PATTERNS:
        if pat.search(text):
            found.append(label)
            text = pat.sub(label, text)
    return text, found


def is_sensitive(text):
    return bool(redact(str(text))[1]) or "[REDACTED" in str(text)
