"""LLM wrappers. AnthropicLLM is the real model. MockLLM is a rule-based
offline stand-in used only for testing the plumbing without an API key
(its token counts are rough estimates, so report real numbers with AnthropicLLM)."""
import json, os, re
from dataclasses import dataclass


@dataclass
class LLMResponse:
    content: list
    stop_reason: str
    input_tokens: int = 0
    output_tokens: int = 0


class AnthropicLLM:
    name = "anthropic"

    def __init__(self, model=None):
        import anthropic
        self.client = anthropic.Anthropic()          # reads ANTHROPIC_API_KEY
        self.model = model or os.getenv("AGENT_MODEL", "claude-haiku-5-5")

    def create(self, system, messages, tools):
        r = self.client.messages.create(model=self.model, max_tokens=700, system=system,
                                        messages=messages, tools=tools)
        blocks = []
        for b in r.content:
            if b.type == "text":
                blocks.append({"type": "text", "text": b.text})
            elif b.type == "tool_use":
                blocks.append({"type": "tool_use", "id": b.id, "name": b.name, "input": b.input})
        return LLMResponse(blocks, r.stop_reason, r.usage.input_tokens, r.usage.output_tokens)


class MockLLM:
    name = "mock"
    _n = 0

    def _resp(self, system, messages, blocks, stop):
        tin = (len(system) + len(json.dumps(messages))) // 4
        tout = len(json.dumps(blocks)) // 4
        return LLMResponse(blocks, stop, tin, tout)

    def _call(self, name, args):
        MockLLM._n += 1
        return [{"type": "tool_use", "id": f"mock_{MockLLM._n}", "name": name, "input": args}]

    def create(self, system, messages, tools):
        last = messages[-1]["content"]
        if isinstance(last, list):                                   # tool results -> final answer
            res = [json.loads(b["content"]) for b in last]
            return self._resp(system, messages, [{"type": "text", "text": self._summarise(res)}], "end_turn")
        msg, low = last, last.lower()
        sid = re.search(r"\bS\d{4}\b", msg, re.I)
        a = {"student_id": sid.group(0).upper()} if sid else {}
        ch = re.search(r"change (?:my |the )?(email|phone|elective)\b.*?\bto (.+?)\.?$", msg, re.I)
        if ch:
            return self._resp(system, messages, self._call("request_record_change", {**a, "field": ch.group(1).lower(), "new_value": ch.group(2)}), "tool_use")
        if msg.strip().endswith("?") and ("prefer" in low or "which programme" in low):
            mem = re.findall(r"^- (.+)$", system, re.M)
            txt = "From my memory: " + "; ".join(mem) if mem else "I don't have that saved."
            return self._resp(system, messages, [{"type": "text", "text": txt}], "end_turn")
        if "remember" in low and ("otp" in low or "password" in low):
            return self._resp(system, messages, self._call("save_memory", {"key": "preferred_contact", "value": msg}), "tool_use")
        if "remember" in low or "i prefer" in low:
            m = re.search(r"by (\w+)", msg)
            return self._resp(system, messages, self._call("save_memory", {"key": "preferred_contact", "value": m.group(1) if m else msg}), "tool_use")
        if "prefer" in low or "which programme" in low:
            mem = re.findall(r"^- (.+)$", system, re.M)
            txt = "From my memory: " + "; ".join(mem) if mem else "I don't have that saved."
            return self._resp(system, messages, [{"type": "text", "text": txt}], "end_turn")
        if "support request" in low or "raise a ticket" in low:
            return self._resp(system, messages, self._call("create_support_request", {"category": "fees", "description": msg}), "tool_use")
        if re.search(r"portal|policy|deadline|late|hostel|curfew|refund|attendance|id card|instalment|cgpa|credited", low):
            return self._resp(system, messages, self._call("search_policy", {"query": msg}), "tool_use")
        if "fee" in low:
            return self._resp(system, messages, self._call("get_fee_status", a), "tool_use")
        if "scholarship" in low:
            return self._resp(system, messages, self._call("get_scholarship_status", a), "tool_use")
        if re.search(r"phone|email|record|details|programme", low):
            return self._resp(system, messages, self._call("get_student_record", a), "tool_use")
        return self._resp(system, messages, [{"type": "text", "text": "Hello! How can I help you today?"}], "end_turn")

    @staticmethod
    def _summarise(res):
        out = []
        for r in res:
            if "error" in r:
                out.append(f"Sorry, I couldn't do that: {r['message']}")
            elif r.get("status") == "approval_required":
                out.append(f"This change needs programme-office approval and is NOT applied yet (ref {r['approval_id']}).")
            elif r.get("status") == "applied":
                out.append(f"Done, {r['field']} is now {r['new_value']}.")
            elif r.get("status") == "created":
                out.append(f"I created support request {r['request_id']}.")
            elif r.get("status") == "saved":
                out.append("Noted, I'll remember that.")
            elif "chunks" in r:
                out.append(" ".join(f"[{c['id']}] {c['text']}" for c in r["chunks"]) or "I couldn't find that in the handbook, so I can't answer it. I can raise a support request.")
            elif "due" in r:
                out.append(f"Student {r['student_id']}: total Rs {r['total']:,}, paid Rs {r['paid']:,}, due Rs {r['due']:,} (due date {r['due_date']}), status: {r['status']}.")
            elif "disbursement" in r:
                out.append(f"Scholarship: {r['name']} - {r['status']}, amount Rs {r['amount']:,}.")
            elif "email" in r:
                out.append(f"{r['name']} ({r['student_id']}): programme {r['programme']}, email {r['email']}, phone {r['phone']}, elective {r['elective']}.")
        return " ".join(out)
