"""Policy retrieval: split the handbook into chunks (one per '## [ID] Title'
section) and rank them with BM25. Only the top few relevant chunks are
returned, never the whole document."""
import math, re
from collections import Counter
from pathlib import Path

STOP = set("a an the is are was were be been am i my me we our you your to of in on for and or can do "
           "does did it this that with at by from as if what how when which who will would should could "
           "please about have has had not no there any get want need".split())


def tokenize(text):
    out = []
    for w in re.findall(r"[a-z0-9]+", text.lower()):
        if w in STOP:
            continue
        if len(w) > 3 and w.endswith("ies"):
            w = w[:-3] + "y"
        elif len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        if len(w) > 5 and w.endswith("ing"):
            w = w[:-3]
        elif len(w) > 4 and w.endswith("ed"):
            w = w[:-2]
        out.append(w)
    return out


class Retriever:
    def __init__(self, path):
        self.chunks = []
        for block in re.split(r"\n(?=## )", Path(path).read_text()):
            m = re.match(r"## \[([A-Z]+-\d+)\] ([^\n]+)\n(.*)", block, re.S)
            if m:
                cid, title, body = m.group(1), m.group(2).strip(), m.group(3).strip()
                self.chunks.append({"id": cid, "title": title, "text": body,
                                    "tokens": tokenize(title + " " + body)})
        self.N = len(self.chunks)
        self.df = Counter(t for c in self.chunks for t in set(c["tokens"]))
        self.avg = sum(len(c["tokens"]) for c in self.chunks) / max(self.N, 1)

    def search(self, query, k=2, min_score=1.2):
        q = set(tokenize(query))
        scored = []
        for c in self.chunks:
            tf = Counter(c["tokens"]); score = 0.0
            for t in q:
                if t not in tf:
                    continue
                idf = math.log(1 + (self.N - self.df[t] + 0.5) / (self.df[t] + 0.5))
                score += idf * tf[t] * 2.5 / (tf[t] + 1.5 * (0.25 + 0.75 * len(c["tokens"]) / self.avg))
            if score >= min_score:
                scored.append({"id": c["id"], "title": c["title"], "text": c["text"], "score": round(score, 2)})
        return sorted(scored, key=lambda x: -x["score"])[:k]
