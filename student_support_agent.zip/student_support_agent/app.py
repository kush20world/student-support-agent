"""Chat UI.  Run:  streamlit run app.py
Demo logins (ID / PIN):  S1001/1111  S1002/2222  S1003/3333  STAFF01/9999 (approver)"""
import os
import pandas as pd
import streamlit as st
from agent.store import Store, SEED
from agent.retrieval import Retriever
from agent.agent import Agent
from agent.security import authenticate
from agent.tools import resolve_approval

st.set_page_config(page_title="Student Support Agent", page_icon="🎓")

if "store" not in st.session_state:
    st.session_state.store = Store()
    if os.getenv("ANTHROPIC_API_KEY"):
        from agent.llm import AnthropicLLM; llm = AnthropicLLM()
    else:
        from agent.llm import MockLLM; llm = MockLLM()
    st.session_state.llm_name = llm.name
    st.session_state.agent = Agent(st.session_state.store, Retriever(SEED / "handbook.md"), llm)
store, agent = st.session_state.store, st.session_state.agent

# ---------------- login ----------------
with st.sidebar:
    st.header("Sign in")
    if "user" not in st.session_state:
        uid = st.text_input("Student / staff ID"); pin = st.text_input("PIN", type="password")
        if st.button("Sign in"):
            u = authenticate(store, uid, pin)
            if u:
                st.session_state.user, st.session_state.chat = u, agent.new_chat(u); st.session_state.msgs = []; st.rerun()
            else:
                st.error("Invalid ID or PIN")
    else:
        u = st.session_state.user
        st.success(f"{u.name} ({u.student_id}, {u.role})")
        if st.button("New chat session"):
            st.session_state.chat, st.session_state.msgs = agent.new_chat(u), []; st.rerun()
        if st.button("Sign out"):
            for k in ("user", "chat", "msgs"): st.session_state.pop(k, None)
            st.rerun()
    if st.session_state.llm_name == "mock":
        st.warning("No ANTHROPIC_API_KEY found: running the offline mock model.")

if "user" not in st.session_state:
    st.title("🎓 Student Support Agent"); st.info("Please sign in from the sidebar."); st.stop()
user = st.session_state.user

# ---------------- staff: approval queue + audit ----------------
if user.role == "staff":
    st.title("Programme office: approval queue")
    pending = [a for a in store.approvals() if a["status"] == "pending"]
    if not pending: st.write("No pending approvals.")
    for a in pending:
        with st.container(border=True):
            st.write(f"**{a['id']}** - student {a['student_id']} wants to change **{a['field']}** "
                     f"from `{a['old_value']}` to `{a['new_value']}`")
            c1, c2 = st.columns(2)
            if c1.button("Approve", key="ok" + a["id"]):
                resolve_approval(store, user, a["id"], True); st.rerun()
            if c2.button("Reject", key="no" + a["id"]):
                resolve_approval(store, user, a["id"], False); st.rerun()
    st.subheader("Audit log")
    log = store.audit_log()
    if log: st.dataframe(pd.DataFrame(log).iloc[::-1], width="stretch")
    st.stop()

# ---------------- student chat ----------------
st.title("🎓 Student Support Agent")
for m in st.session_state.msgs:
    with st.chat_message(m["role"]):
        st.write(m["content"])
        if m.get("trace"):
            t = m["trace"]
            with st.expander("Trace"):
                st.json({k: t[k] for k in ("run_id", "tools", "policy_chunks", "memory_used", "redactions",
                                          "llm_calls", "input_tokens", "output_tokens", "latency_s")})
if q := st.chat_input("Ask about fees, scholarships, course changes..."):
    st.session_state.msgs.append({"role": "user", "content": q})
    with st.spinner("Thinking..."):
        t = agent.chat(st.session_state.chat, q)
    st.session_state.msgs.append({"role": "assistant", "content": t["answer"], "trace": t}); st.rerun()

mine = [a for a in store.approvals() if a["student_id"] == user.student_id]
if mine:
    st.sidebar.subheader("My change requests")
    for a in mine: st.sidebar.write(f"{a['id']}: {a['field']} → {a['status']}")
