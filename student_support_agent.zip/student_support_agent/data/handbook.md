# Student Policy Handbook (PGDM 2025-27)

## [FEE-01] Fee deadlines and late fees
Each instalment must be paid by its due date shown in the student portal. A late fee of Rs 500 per day applies after the due date, capped at Rs 5,000. Fees can be paid through the online payment portal, by demand draft, or at the accounts counter.

## [FEE-02] Payment portal failure
If the online payment portal fails or the payment does not go through, the student must take a screenshot of the error or the bank debit message and raise a support request on the same day. When the failure is documented this way, payment on the next working day is accepted and the late fee is waived. Without a screenshot and a same-day support request, the normal late fee applies.

## [FEE-03] Instalment plans
A student may request to split an outstanding balance into two instalments by raising a support request to the accounts office before the due date. Approval takes up to 3 working days. Instalment requests made after the due date are not accepted.

## [SCH-01] Merit scholarship
The Merit Scholarship is awarded to students with a CGPA of 8.0 or above at the end of the previous semester. It is renewed every semester. The scholarship amount is credited to the student's fee account and is not paid in cash.

## [SCH-02] Need-based scholarship
Need-based scholarships require income documents and are decided by the scholarship committee within 30 days of application. Students can check the status through the support desk.

## [CRS-01] Elective and course changes
An elective can be changed only within the first 2 weeks of the semester. A student may change an elective once per semester. Every change needs approval from the programme office and is applied to the student record only after approval.

## [SUP-01] Support requests
Support requests are answered within 2 working days. Urgent fee issues are answered within 1 working day. A student must describe the problem and include relevant details such as transaction reference numbers.

## [ATT-01] Attendance
A minimum attendance of 75 percent is required in each course to sit the end-term examination. Medical leave needs a certificate submitted within 5 working days of returning.

## [ID-01] ID card replacement
A lost ID card can be replaced by paying a fee of Rs 300 at the accounts counter and submitting an application to the programme office. A new card is issued within 5 working days.

## [PRV-01] Privacy and account security
Staff and the support agent will never ask for a password, OTP or card PIN. Never share these in chat. Changes to contact details or enrolment data are sensitive and are made only after the programme office has approved the request.
